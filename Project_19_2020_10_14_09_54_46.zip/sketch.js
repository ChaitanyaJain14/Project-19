var banana,bananaImage,bananaGroup
var stone,stoneGroup,stoneImage
var ground
var score=0;
var monkey
var invisibleGround
var END=1;


function preload(){
  backImage=loadImage("jungle.jpg");
  
  monkey_running=loadAnimation("Monkey_01.png","Monkey_02.png","Monkey_03.png","Monkey_04.png","Monkey_05.png","Monkey_06.png","Monkey_07.png","Monkey_08.png","Monkey_09.png","Monkey_10.png");
  
  bananaImage=loadImage("banana.png");
  stoneImage=loadImage("stone.png");
}

function setup() {
  createCanvas(400, 400);
  
  ground = createSprite(200,365,400,20);
  ground.addImage("ground",jungle.jpg);
  ground.x = ground.width/2;
  ground.velocityX=-5;
  
  invisibleGround = createSprite(200,395,400,5)
  invisibleGround.visible=false;
  
  monkey=createSprite(30,365,20,20);
  monkey.addAnimation("running",monkey_running);
  
  banana=createSprite(400,200,20,20);
  banana.addImage("banana",banana.png);
  banana.velocityX=-6;
  
  stone=createSprite(400,380,10,40);
  stone.addImage("stone",stone.png);
  stone.velocityX=-8;
  
}

function draw() {
  background(255);
  
  
  text("Score: "+score,300,100);
  
  spawnObstacles();
  spawnFood();
  
  if(monkey.isTouching(bananaGroup)){
     monkey.scale=monkey.scale+0.005;
  }
  
  if(monkey.isTouching(stoneGroup)){
    gameState=END;
  }
  
  if(gameState===END){
    stoneGroup.velocityX=0;
    monkey.velocityX=0;
    bananaGroup.velocityX=0;
  }
  
  drawSprites();
}

function spawnObstacles(){
  if (frameCount%60===0){
    var stone=createSprite(400,380,10,40);
    
  
    stone.scale=0.5;
    stone.velocityX=-8;
    stone.lifetime=105;
    stoneGroup.add(obstacle);
  }
}

function spawnFood(){
  if (frameCount%40===0){
     var banana=createSprite(400,200,20,20);
    
    banana.velocityX=-6;
    bananaGroup.add(banana);
  }
}

